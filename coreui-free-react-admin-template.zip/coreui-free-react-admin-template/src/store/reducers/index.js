import rootReducers from "./rootReducers";
export default rootReducers;