import { combineReducers } from "redux";
import auth from "./auth";
import dashboard from './dashboard';
import profile from "./profile";
import user from './user';
import resturant from './resturant';
import email from './email';
import cms from './cms';
import settings from './settings';
import category from './category';
export default combineReducers({
    auth,
    dashboard,
    profile,
    user,
    resturant,
    email,
    cms,
    settings,
    category,
})