import {setItemAction,resetItemAction} from '../../shared/commonUpdateState';
const initialState = {
    setting: null,
    // settingsList: [],
    action: {
        type: null,
        isSuccess: false,
        data: null
    },
    isLoading: false
}
export default function (state = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case 'SET_SETTINGS_ACTION' : return setItemAction(state, payload,'SETTINGS');
        case 'RESET_SETTINGS_ACTION' : return resetItemAction(state,'SETTINGS');
        default: return state
    }
}