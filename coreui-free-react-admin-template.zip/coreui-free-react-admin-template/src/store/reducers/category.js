import {setItemAction,resetItemAction} from '../../shared/commonUpdateState';
const initialState = {
    category: null,
    categoryList: [],
    action: {
        type: null,
        isSuccess: false,
        data: null
    },
    isLoading: false
}
export default function (state = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case 'SET_CATEGORY_ACTION' : return setItemAction(state, payload,'CATEGORY');
        case 'RESET_CATEGORY_ACTION' : return resetItemAction(state,'CATEGORY');
        default: return state
    }
}