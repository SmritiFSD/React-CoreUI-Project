import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Col,
  Form,
  Row,
  Label,
} from "reactstrap";
import DropdownTreeSelect from "react-dropdown-tree-select";
import data1 from "./list-data1";
import data2 from "./list-data2";
import data3 from "./list-data3";
import data4 from "./list-data4";

import "react-dropdown-tree-select/dist/styles.css";
import CheckboxUI from "../../UI/CheckboxInputUI";
import { CATEGORY_URL } from "../../shared/allApiUrl";
import { crudAction } from "../../store/actions/common";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

function Category(props) {
  const initialFields = {
    breakfast:'',
    lunch:'',
    dinner:'',
    drinks:'',
    menu:''
  };
  const [fields, setFields] = useState(initialFields);
  const [categoryId, setCategoryId] = useState(null);
  const { handleSubmit, register, errors } = useForm();
  const params = props.match.params;
  useEffect(() => {
    setCategoryId(params.categoryId);
    if (params.categoryId)
      props.crudActionCall(`${CATEGORY_URL}/${params.categoryId}`, null, "GET");
  }, [params]);
  useEffect(() => {
    const action = props.category.action;
    if (props.category.category && params.categoryId) {
      setFields({ ...fields, ...props.category.category });
    }

    if ((action.isSuccess && action.type === "ADD") || action.type === "UPDATE")
      props.history.push("/category/list");
  }, [props.category]);
  const onSubmit = (data) => {
    if (categoryId) data.categoryId = categoryId;
    console.log("data====>>", data);
    props.crudActionCall(CATEGORY_URL, data, categoryId ? "UPDATE" : "ADD");
  };
  const onChange = (currentNode, selectedNodes) => {
    console.log("onChange::", currentNode, selectedNodes);
  };
  const onAction = (node, action) => {
    console.log("onAction::", action, node);
  };
  const onNodeToggle = (currentNode) => {
    console.log("onNodeToggle::", currentNode);
  };
 
  return (
    <div className="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <CardHeader>
              <i className="fa fa-edit"></i>
              {categoryId ? `Category Update` : `Category Add`}
            </CardHeader>
            <Form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
              <CardBody>
                <Label>BREAKFAST&nbsp;&nbsp;</Label>
                <DropdownTreeSelect
                  ref={register({ name: "breakfast" })}
                  data={data1}
                  onChange={onChange}
                  onAction={onAction}
                  onNodeToggle={onNodeToggle}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="GF - Gluten free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="DF - dairy free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="Egg - contains egg"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="V - vegetarian"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="VG - vegan"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  inline
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                  label="KT - keto"
                />
              </CardBody>
              <CardBody>
                <Label>LUNCH&nbsp;&nbsp;</Label>
                <DropdownTreeSelect
                  data={data2}
                  onChange={onChange}
                  onAction={onAction}
                  onNodeToggle={onNodeToggle}
                  ref={register({ name: "lunch" })}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="GF - Gluten free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="DF - dairy free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="Egg - contains egg"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="V - vegetarian"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="VG - vegan"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                  label="KT - keto"
                />
              </CardBody>
              <CardBody>
                <Label>DINNER&nbsp;&nbsp;</Label>
                <DropdownTreeSelect
                
                  data={data3}
                  onChange={onChange}
                  onAction={onAction}
                  onNodeToggle={onNodeToggle}
                  ref={register({ name: "dinner" })}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="GF - Gluten free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="DF - dairy free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="Egg - contains egg"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="V - vegetarian"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="VG - vegan"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                  label="KT - keto"
                />
              </CardBody>
              <CardBody>
                <Label>DRINKS&nbsp;&nbsp;</Label>
                <DropdownTreeSelect
                  data={data4}
                  onChange={onChange}
                  onAction={onAction}
                  onNodeToggle={onNodeToggle}
                  ref={register({ name: "drinks" })}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="GF - Gluten free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="DF - dairy free"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="Egg - contains egg"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="V - vegetarian"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  label="VG - vegan"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                />
                <CheckboxUI
                  className="form-check-input"
                  type="checkbox"
                  id="manu"
                  name="menu"
                  errors={errors}
                  innerRef={register}
                  fields={fields}
                  label="KT - keto"
                />
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="success">
                  <i className="fa fa-dot-circle-o"></i> Submit
                </Button>
              </CardFooter>
            </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
const mapStateToProps = (state) => {
  const { category } = state;
  return {
    category,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    crudActionCall: (url, data, actionType) =>
      dispatch(crudAction(url, data, actionType, "CATEGORY")),
    resetAction: () => dispatch({ type: "RESET_CATEGORY_ACTION" }),
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(Category));
