import React, { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Col,
  Form,
  Row,
} from 'reactstrap';
import InputUI from '../../UI/InputUI';
import FileInput from "../../UI/FileInput";
import { getImageUrl } from '../../shared/helpers';
import { SETTINGS_URL } from '../../shared/allApiUrl';
import { crudAction } from '../../store/actions/common';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

function SettingsForm(props) {
  const initialFields = {
    name: "",
    siteEmail: "",
    sitePhoneNumber:"",
    paymentEnvironment: "",
    siteAddress: "",
    instagramUrl: "",
    facebookUrl: "",
    tweeterUrl: "",
    linkedinUrl: "",
  }
  const [fields, setFields] = useState(initialFields);
  const [settingsId, setSettingsId] = useState(null);
  const { handleSubmit, register, errors } = useForm();
  const params = props.match.params;
  useEffect(() => {
    setSettingsId(params.settingsId)
    if (params.settingsId) props.crudActionCall(`${SETTINGS_URL}/${params.settingsId}`, null, "GET")
  }, [params])
  useEffect(() => {
    const action = props.settings.action;
    if (props.settings.settings && params.settingsId) {
      setFields({ ...fields, ...props.settings.settings })
    }

    if (action.isSuccess && action.type === "ADD" || action.type === "UPDATE")
      props.history.push("/settings/list")

  }, [props.settings]);
  const onSubmit = (data) => {
    console.log(data)
    if (settingsId) data.settingsId = settingsId;
    props.crudActionCall(SETTINGS_URL, data, settingsId ? "UPDATE" : "ADD")
  }
  return (
    <div className="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <CardHeader>
              <i className="fa fa-edit"></i>{settingsId ? `User Update` : `User Add`}
            </CardHeader>
            <Form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
              <CardBody>
                {/* First Name */}
                <InputUI
                  label="Web Name"
                  name="name"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                {/* Email-ID */}
                <InputUI
                  label="Contact Email"
                  name="siteEmail"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Web Phone"
                  name="sitePhoneNumber"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Payment Email"
                  name="paymentEnvironment"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
               
                {/* Address */}
                <InputUI
                  label="Address"
                  name="siteAddress"
                  type="text"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Instagram"
                  name="instagramUrl"
                  type="text"
                  placeholder='https://www.instagram.com'
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Facebook"
                  name="facebookUrl"
                  type="text"
                  placeholder='https://www.facebook.com'
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Linkedin"
                  name="linkedinUrl"
                  type="text"
                  placeholder='https://www.linedin.com'
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <InputUI
                  label="Tweeter"
                  name="tweeterUrl"
                  type="text"
                  placeholder='https://www.tweeter.com'
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                <div className="text-center" style={{ height: 150 }}>
                  {/* <img src={getImageUrl(fields.logo)} className="rounded-circle" style={{ height: "100%" }} alt="..." /> */}
                  <img src={'http://111.93.169.90:4020/image/user.png'} class="rounded-circle" width="200" />
                </div>
                <FileInput
                  label="Logo"
                  name="logo"
                  register={register}
                  errors={errors}
                  required={false}
                  fields={fields}
                />
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o"></i> Submit</Button>
              </CardFooter>
            </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
const mapStateToProps = state => {
  const { settings } = state;
  return {
    settings
  }
}
const mapDispatchToProps = dispatch => {
  return {
    crudActionCall: (url, data, actionType) => dispatch(crudAction(url, data, actionType, "SETTINGS")),
    resetAction: () => dispatch({ type: "RESET_SETTINGS_ACTION" })
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(SettingsForm));