import React, { useState, useEffect } from 'react';
import { Button,  Form,  Label, Input, Row, Col } from 'reactstrap';
import { useForm } from "react-hook-form";
import { EMAIL_URL } from '../../shared/allApiUrl';

import { crudAction } from '../../store/actions/common';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import {
 
  Card,
  CardBody,
  CardHeader,
  CardFooter,
} from 'reactstrap';
import CKEditor from 'ckeditor4-react';
import InputUI from "../../UI/InputUI";
function Compose(props) {
  const initialFields = {
    emailSubject:'',
    emailContent:''
    
  }
  const [fields, setFields] = useState(initialFields);
  const [emailId, setEmailId] = useState(null);
  const { handleSubmit, register,errors,setValue } = useForm();
  const params = props.match.params;
  useEffect(() => {
    setEmailId(params.emailId)
    if (params.emailId) props.crudActionCall(`${EMAIL_URL}/${params.emailId}`, null, "GET")
  }, [params])
  useEffect(() => {
    const action = props.email.action;
    if (props.email.email && params.emailId) {
      setFields({ ...fields, ...props.email.email })
    }

    if (action.isSuccess && action.type === "ADD" || action.type === "UPDATE")
      props.history.push("/email/list")

  }, [props.email]);
  const onSubmit = (data) => {
    console.log(data)
    if (emailId) data.emailId = emailId;
    props.crudActionCall(EMAIL_URL, data, emailId ? "UPDATE" : "ADD")
  }
  return (
    <div className="animated fadeIn">
    <Row>
      <Col xs="12">
        <Card>
      <Form  className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
      <CardBody>
        
          {/* strange reactstrap sizing for Label: className="col-2 col-sm-1 col-form-label" */}
          <Label for="title" xs={4} sm={2}>Email Subject:</Label>
            <InputUI
                  name="emailSubject"
                  errors={errors}
                  innerRef={register({
                    required: "This is required field",
                  })}
                  fields={fields}
                />
        <div className="text-editor">
        
        <Label for="cke_editor" xs={9} sm={9}>Email Content:</Label><br/>
            {/* <Input type="textarea" id="message" name="body" rows="12" placeholder="Click here to reply"></Input> */}
            <CKEditor
                  data={fields.emailContent || ""}
                  config={{ allowedContent: true }}
                  onInit={(editor) => {
                    // You can store the "editor" and use when it is needed.
                    console.log("Editor is ready to use!", editor);
                  }}
                  onChange={(event, editor) => {
                    const data = event.editor.getData();
                    setValue("emailContent", data);
                    console.log({ event, editor, data });
                  }}
                  ref={register({ name: "emailContent" })}
                />
          </div>
          </CardBody>
          <CardFooter>
                <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o"></i> Submit</Button>
          </CardFooter>
      </Form>
      </Card>
      </Col>
    </Row>
  </div>
  );
}
const mapStateToProps = state => {
  const { email } = state;
  return {
    email
  }
}
const mapDispatchToProps = dispatch => {
  return {
    crudActionCall: (url, data, actionType) => dispatch(crudAction(url, data, actionType, "EMAIL")),
    resetAction: () => dispatch({ type: "RESET_EMAIL_ACTION" })
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Compose));