import React, {useEffect} from 'react'
import {
    Card,
    CardBody,
    CardHeader,
    Col,
    Row,
  } from 'reactstrap';
import '../../custom.css';
import { connect } from "react-redux";
import { crudAction } from "../../store/actions/common";
import { EMAIL_URL } from '../../shared/allApiUrl';
import { getImageUrl } from '../../shared/helpers';
import moment from 'moment'

function EmailDetails(props) {
    let emailId = props.match.params.emailId;
    useEffect( () => {
        props.crudActionCall(`${EMAIL_URL}/${emailId}`, null, "GET")
        return () => {
            
        }
    }, []);
    
    const emailData = props.email.email;
    return (
        <div classNam="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <CardHeader>
              <i classNameName="fa fa-edit"></i>View Profile
                </CardHeader>
              <CardBody>
                {emailData && (
              <ul className="list-unstyled todo-list">
                <li>
                    <p>
                        <span className="title">Email Content</span>
                        <span className="short-description">{`${emailData.data}`}</span>
                    </p>
                </li>               
                <li>
                    <p>
                        <span className="title">Status</span>
                        <span className="short-description">{emailData.status==1 ? "Active" : "Inactive"}</span>
                    </p>
                </li>
                </ul>
                )}
              </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
    )
}
const mapStateToProps = state => {
    const { email } = state;
    return {
        email
    }
  }
  const mapDispatchToProps = dispatch => {
    return {
      crudActionCall: (url, data, actionType) => dispatch(crudAction(url, data, actionType, "EMAIL"))
    }
  }
export default connect(mapStateToProps, mapDispatchToProps)(EmailDetails);