import React, { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Col,
  Form,
  Row,
} from 'reactstrap';
import InputUI from '../../UI/InputUI';
import FileInput from "../../UI/FileInput";
import { RESTURANT_URL } from '../../shared/allApiUrl';
import { crudAction } from '../../store/actions/common';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

function ResturantForm(props) {
  const initialFields = {
    name: "",
    location: "",
    owner:'',
    profilePicture:''
  }
  const [fields, setFields] = useState(initialFields);
  const [resturantId, setResturantId] = useState(null);
  const { handleSubmit, register, errors } = useForm();
  const params = props.match.params;
  useEffect(() => {
    setResturantId(params.resturantId)
    if (params.resturantId) props.crudActionCall(`${RESTURANT_URL}/${params.resturantId}`, null, "GET")
  }, [params])
  useEffect(() => {
    const action = props.resturant.action;
    if (props.resturant.resturant && params.resturantId) {
      setFields({ ...fields, ...props.resturant.resturant })
    }

    if (action.isSuccess && action.type === "ADD" || action.type === "UPDATE")
      props.history.push("/resturant/list")

  }, [props.resturant]);
  const onSubmit = (data) => {
    if (resturantId) data.resturantId = resturantId;
    props.crudActionCall(RESTURANT_URL, data, resturantId ? "UPDATE" : "ADD")
  }
  return (
    <div className="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <CardHeader>
              <i className="fa fa-edit"></i>{resturantId ? `Resturent Update` : `Resturent Add`}
            </CardHeader>
            <Form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
              <CardBody>
                {/* First Name */}
                <InputUI
                  label="Name"
                  name="name"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  
                  fields={fields}
                />
                
                <InputUI
                  label="Location"
                  name="location"
                  errors={errors}
                  innerRef={register({
                    required: 'This is required field',
                  })}
                  fields={fields}
                />
                
                {/* Owner */}
                <InputUI
                  label="Owner"
                  name="owner"
                  type="text"
                  errors={errors}
                  innerRef={register({
                  required: 'This is required field',
                  })}
                
                  fields={fields}
                />
                <FileInput
                  label="Resturent Icon"
                  name="profilePicture"
                  register={register}
                  errors={errors}
                  required={false}
                />
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o"></i> Submit</Button>
              </CardFooter>
            </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
const mapStateToProps = state => {
  const { resturant } = state;
  return {
    resturant
  }
}
const mapDispatchToProps = dispatch => {
  return {
    crudActionCall: (url, data, actionType) => dispatch(crudAction(url, data, actionType, "RESTURANT")),
    resetAction: () => dispatch({ type: "RESET_RESTURANT_ACTION" })
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(ResturantForm));