import React, { useState, useEffect } from "react";
import { Button, Form, Label, Input, Row, Col } from "reactstrap";
import { useForm } from "react-hook-form";
import { CMS_URL } from "../../shared/allApiUrl";
import { crudAction } from "../../store/actions/common";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { Card, CardBody, CardFooter } from "reactstrap";
import CKEditor from "ckeditor4-react";
import InputUI from "../../UI/InputUI";
// import 'react-draft-wysiwyg.css';
function CmsForm(props) {
  const initialFields = {
    cmsTitle: "",
    cmsContent: "",
  };
  const [fields, setFields] = useState(initialFields);
  const [cmsId, setCmsId] = useState(null);
  // const [cmsId, setCmsId] = useState(null);
  const { handleSubmit, register, errors,setValue } = useForm();

  const params = props.match.params;
  useEffect(() => {
    setCmsId(params.cmsId);
    if (params.cmsId)
      props.crudActionCall(`${CMS_URL}/${params.cmsId}`, null, "GET");
  }, [params]);
  useEffect(() => {
    const action = props.cms.action;
    if (props.cms.cms && params.cmsId) {
      setFields({ ...fields, ...props.cms.cms });
    }

    if ((action.isSuccess && action.type === "ADD") || action.type === "UPDATE")
      props.history.push("/cms/list");
  }, [props.cms]);
  const onSubmit = (data) => {
    // console.log("data====>>", data);
    if (cmsId) data.cmsId = cmsId;
    props.crudActionCall(CMS_URL, data, cmsId ? "UPDATE" : "ADD");
  };

  return (
    <div className="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <Form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
              <CardBody>
                {/* strange reactstrap sizing for Label: className="col-2 col-sm-1 col-form-label" */}
                <Label for="title" xs={4} sm={2}>
                  Page Title:
                </Label>
                {/* <Input type="text" name="cmsTitle" placeholder="" /> */}
                <InputUI
                  name="cmsTitle"
                  errors={errors}
                  innerRef={register({
                    required: "This is required field",
                  })}
                  fields={fields}
                />
                <Label for="cke_editor" xs={9} sm={9}>
                  Page Content:
                </Label>
                {/* <CKEditor name="cmsContent" data="<p></p>" /> */}
                <CKEditor
                  data={fields.cmsContent || ""}
                  config={{ allowedContent: true }}
                  onInit={(editor) => {
                    // You can store the "editor" and use when it is needed.
                    console.log("Editor is ready to use!", editor);
                  }}
                  onChange={(event, editor) => {
                    const data = event.editor.getData();
                    setValue("cmsContent", data);
                    console.log({ event, editor, data });
                  }}
                  ref={register({ name: "cmsContent" })}
                />
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="success">
                  <i className="fa fa-dot-circle-o"></i> Submit
                </Button>
              </CardFooter>
            </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
const mapStateToProps = (state) => {
  const { cms } = state;
  return {
    cms,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    crudActionCall: (url, data, actionType) =>
      dispatch(crudAction(url, data, actionType, "CMS")),
    resetAction: () => dispatch({ type: "RESET_CMS_ACTION" }),
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(CmsForm));
