import React, {useEffect} from 'react'
import {
    Card,
    CardBody,
    CardHeader,
    Col,
    Row,
  } from 'reactstrap';
import '../../custom.css';
import { connect } from "react-redux";
import { crudAction } from "../../store/actions/common";
import { CMS_URL } from '../../shared/allApiUrl';
// import { getImageUrl } from '../../shared/helpers';
// import moment from 'moment'

function CmsDetails(props) {
    let cmsId = props.match.params.cmsId;
    useEffect( () => {
        props.crudActionCall(`${CMS_URL}/${cmsId}`, null, "GET")
        return () => {
            
        }
    }, []);
    
    const cmsData = props.cms.cms;
    return (
        <div classNam="animated fadeIn">
      <Row>
        <Col xs="12">
          <Card>
            <CardHeader>
              <i classNameName="fa fa-edit"></i>View Profile
                </CardHeader>
              <CardBody>
                {cmsData && (
              <ul className="list-unstyled todo-list">
              <li>
                    <p>
                        <span className="title">Input Content</span>
                        <span className="short-description">{`${cmsData.body}`}</span>
                    </p>
                </li>               
                <li>
                    <p>
                        <span className="title">Status</span>
                        <span className="short-description">{cmsData.status==1 ? "Active" : "Inactive"}</span>
                    </p>
                </li>
                </ul>
                )}
              </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
    )
}
const mapStateToProps = state => {
    const { cms } = state;
    return {
        cms
    }
  }
  const mapDispatchToProps = dispatch => {
    return {
      crudActionCall: (url, data, actionType) => dispatch(crudAction(url, data, actionType, "CMS"))
    }
  }
export default connect(mapStateToProps, mapDispatchToProps)(CmsDetails);