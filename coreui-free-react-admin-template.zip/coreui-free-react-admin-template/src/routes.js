import React from 'react';

const Dashboard = React.lazy(() => import('./containers/Dashboard/Dashboard'));
const Profile = React.lazy(() => import('./containers/Profile'));
const ChangePass = React.lazy(() => import('./containers/Profile/ChangePassword'));
const UserForm = React.lazy(() => import('./containers/Users/UserForm'));
const UserList = React.lazy(() => import('./containers/Users/UserList'));
const UserDetails = React.lazy(() => import('./containers/Users/UserDetails'));
const ResturantForm = React.lazy(() => import('./containers/Resturents/ResturantForm'));
const ResturantList = React.lazy(() => import('./containers/Resturents/ResturantList'));
const ResturantDetails = React.lazy(() => import('./containers/Resturents/ResturantDetails'));
const Compose = React.lazy(() => import('./containers/Email/Compose'));
const EmailList = React.lazy(() => import('./containers/Email/EmailList'));
const EmailDetails = React.lazy(() => import('./containers/Email/EmailDetails'));
const CmsForm = React.lazy(() => import('./containers/Cms/CmsForm'));
const CmsList = React.lazy(() => import('./containers/Cms/CmsList'));
const CmsDetails = React.lazy(() => import('./containers/Cms/CmsDetails'));
const SettingsForm = React.lazy(() => import('./containers/Settings/SettingsForm'));
const Category = React.lazy(() => import('./containers/Category/Category'));
const CategoryList = React.lazy(() => import('./containers/Category/CategoryList'));
const CategoryDetails = React.lazy(() => import('./containers/Category/CategoryDetails'));
// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/profile', exact: true, name: 'Prifile', component: Profile },
  { path: '/change-password', name: 'Change Password', component: ChangePass },

  //------------------------------ Manage User --------------------------------
  { path: '/user', exact: true, name: "Users", component: UserList },
  { path: '/user/add', name: "Add", component: UserForm },
  { path: '/user/edit/:userId', name: "Edit", component: UserForm },
  { path: '/user/list', name: "List", component: UserList },
  { path: '/user/details/:userId', name: "Details", component: UserDetails },

   //------------------------------ Manage Resturant --------------------------------
   { path: '/resturant', exact: true, name: "Resturents", component: ResturantList },
   { path: '/resturant/add', name: "Add", component: ResturantForm },
   { path: '/resturant/edit/:resturantId', name: "Edit", component: ResturantForm },
   { path: '/resturant/list', name: "List", component: ResturantList },
   {path: '/resturant/details/:resturantId', name: "Details", component: ResturantDetails},

    //------------------------------ Email --------------------------------
    { path: '/email', exact: true, name: "Email", component: EmailList },
    { path: '/email/add', name: "Add", component: Compose },
    { path: '/email/edit/:emailId', name: "Edit", component: Compose },
    { path: '/email/list', name: "List", component: EmailList },
    {path: '/email/details/:emailId', name: "Details", component: EmailDetails},
    //------------------------------ Cms --------------------------------
    { path: '/cms', exact: true, name: "Cms", component: CmsList },
    { path: '/cms/add', name: "Add", component: CmsForm },
    { path: '/cms/edit/:cmsId', name: "Edit", component: CmsForm },
    { path: '/cms/list', name: "List", component: CmsList },
    {path: '/cms/details/:cmsId', name: "Details", component: CmsDetails},
    // -------------------------Settings-------------------------------
    { path: '/settings', exact: true, name: "Settings", component: SettingsForm },
    //------------------------------ Category --------------------------------
    { path: '/category', exact: true, name: "Category", component: CategoryList },
    { path: '/category/add', name: "Add", component: Category },
    { path: '/category/edit/:categoryId', name: "Edit", component: Category },
    { path: '/category/list', name: "List", component: CategoryList },
    {path: '/category/details/:categoryId', name: "Details", component: CategoryDetails},
];

export default routes;
