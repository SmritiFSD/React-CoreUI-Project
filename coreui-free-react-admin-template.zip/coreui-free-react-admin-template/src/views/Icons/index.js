import CoreUIIcons from './CoreUIIcons';
import FontAwesome from './FontAwesome';
import SimpleLineIcons from './SimpleLineIcons';

export {
  CoreUIIcons, FontAwesome, SimpleLineIcons
};
