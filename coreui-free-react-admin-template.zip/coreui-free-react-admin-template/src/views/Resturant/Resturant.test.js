import React from 'react';
import {MemoryRouter} from 'react-router-dom';
import { mount } from 'enzyme'
import Resturant from './Resturant';


it('renders without crashing', () => {
  const wrapper = mount(
    <MemoryRouter>
      <Resturant match={{params: {id: "1"}, isExact: true, path: "/resturants/:id", name: "Resturant details"}}/>
    </MemoryRouter>
  );
  expect(wrapper.containsMatchingElement(<strong>Samppa Nori</strong>)).toEqual(true)
  wrapper.unmount()
});
