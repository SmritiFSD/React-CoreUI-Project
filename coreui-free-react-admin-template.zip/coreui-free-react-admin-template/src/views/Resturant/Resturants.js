import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Badge, Card, CardBody, CardHeader, Col, Row, Table } from 'reactstrap';

import resturantsData from './ResturantsData'

function ResturantRow(props) {
  const resturant = props.resturant
  const resturantLink = `/resturants/${resturant.id}`

  const getBadge = (status) => {
    return status === 'Active' ? 'success' :
      status === 'Inactive' ? 'secondary' :
        status === 'Pending' ? 'warning' :
          status === 'Banned' ? 'danger' :
            'primary'
  }

  return (
    <tr key={resturant.id.toString()}>
      <th scope="row"><Link to={resturantLink}>{resturant.id}</Link></th>
      <td><Link to={resturantLink}>{resturant.name}</Link></td>
      <td>{resturant.registered}</td>
      <td>{resturant.role}</td>
      <td><Link to={resturantLink}><Badge color={getBadge(resturant.status)}>{resturant.status}</Badge></Link></td>
    </tr>
  )
}

class Resturants extends Component {

  render() {

    const resturantList = resturantsData.filter((resturant) => resturant.id < 10)

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xl={6}>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Resturants <small className="text-muted">example</small>
              </CardHeader>
              <CardBody>
                <Table responsive hover>
                  <thead>
                    <tr>
                      <th scope="col">id</th>
                      <th scope="col">name</th>
                      <th scope="col">location</th>
                      <th scope="col">owner</th>
                      <th scope="col">status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {resturantList.map((resturant, index) =>
                      <ResturantRow key={index} resturant={resturant}/>
                    )}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Resturants;
