export default {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'icon-speedometer'
    },
    {
      name: 'Manage User',
      url: '/user',
      icon: 'fa fa-users',
      children: [
        {
          name: 'Add',
          url: '/user/add',
          icon: 'fa fa-user-plus',
        },
        {
          name: 'List',
          url: '/user/list',
          icon: 'fa fa-list-alt',
        }
      ]
    },
    {
      name: 'Manage Resturent',
      url: '/resturant',
      icon: 'fa fa-cutlery',
      children: [
        {
          name: 'Add',
          url: '/resturant/add',
          icon: 'fa fa-user-plus',
        },
        {
          name: 'List',
          url: '/resturant/list',
          icon: 'fa fa-list-alt',
        }
      ]
    },
    {
      name: 'Email Template',
      url: '/email',
      icon: 'fa fa-envelope',
      children: [
            {
              name: 'Add',
              url: '/email/add',
              icon: 'fa fa-user-plus',
            },
            {
              name: 'List',
              url: '/email/list',
              icon: 'fa fa-list-alt',
            }
          ],
        },
  {
    name: 'Manage Cms',
    url: '/cms',
    icon: 'fa fa-file',
    children: [
          {
            name: 'Add',
            url: '/cms/add',
            icon: 'fa fa-user-plus',
          },
          {
            name: 'List',
            url: '/cms/list',
            icon: 'fa fa-list-alt',
          }
        ],
      },
      {
        name: 'Manage Category',
        url: '/category',
        icon: 'fa fa-cutlery',
        children: [
          {
            name: 'Add',
            url: '/category/add',
            icon: 'fa fa-cutlery',
          },
          {
            name: 'List',
            url: '/category/list',
            icon: 'fa fa-list-alt',
          }
        ]
      },
      {
        name: 'Settings',
        url: '/settings',
        icon: 'fa fa-gear',
        // children: [
        //       {
        //         name: 'Add',
        //         url: '/settings/add',
        //         icon: 'fa fa-user-plus',
        //       },
              
        //     ],
          },
          
    
  ],
};
