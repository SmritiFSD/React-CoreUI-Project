export const LOGIN_URL = 'admin-api/adminLogin';
export const LOGOUT_URL = '';
export const PROFILE_URL = '';
export const USER_URL = 'user-api/user';
export const RESTURANT_URL = 'resturent-api/resturent';
export const CATEGORY_URL = 'category-api/category';
export const UNIVERSITY_URL = '';
export const CHANGE_PASSWORD_URL = '';
export const SETTINGS_URL = 'setting-api/setting';
export const CMS_URL = 'cms-api/cms';
export const EMAIL_URL = 'email-api/email';
export const ORDER_URL = '';
export const TRIP_URL = '';

